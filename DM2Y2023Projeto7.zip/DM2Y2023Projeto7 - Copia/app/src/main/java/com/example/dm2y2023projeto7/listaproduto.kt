package com.example.dm2y2023projeto7

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class listaproduto : AppCompatActivity() {

    val db = Firebase.firestore

    val listaDados = mutableListOf<newproduto>()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_produto)

        BuscarprodutoFirebase()

        val btnNovoproduto = findViewById<Button>(R.id.btnNovoproduto)

        btnNovoproduto.setOnClickListener{
            val intent = Intent(this, novo_produto::class.java)
            addProductRequest.launch(intent)
        }

        val listaproduto = findViewById<ListView>(R.id.lstprotuto)

        listaproduto.setOnItemLongClickListener { parent, view, position, id ->
            val builder = AlertDialog.Builder(this)
            builder
                .setTitle("APAGAR REGISTRO")
                .setMessage("Deseja deletar o prudoto?")
                .setPositiveButton("Sim") { dialog, which ->
                    val produto = listaDados[position]

                    Excluirproduto(produto.id)
                }
                .setNegativeButton("Não"){ dialog, which ->
                    Toast.makeText(this, "produto não deletado", Toast.LENGTH_LONG).show()
                }
                .show()
            true
        }
    }

    private val addProductRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            BuscarprodutoFirebase()
        }
    }

    private fun BuscarprodutoFirebase() {
        db.collection("produto")
            .get()
            .addOnSuccessListener { querySnapshot ->
                Listarproduto(querySnapshot)
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Falha ao excluir produto", Toast.LENGTH_SHORT).show()
            }
    }

    data class newproduto(
        val id: String,
        val nomeproduto: String,
        val valorproduto: String
    )

    private fun Listarproduto(querySnapshot: QuerySnapshot) {
        listaDados.clear()

        for (document in querySnapshot) {
            val id = document.id
            val nomeproduto = document.getString("nomeproduto")
            val valorproduto = document.getString("valorproduto")

            if (id != null && nomeproduto != null && valorproduto != null) {
                val produto = newproduto(id, nomeproduto, valorproduto)
                listaDados.add(produto)
            }
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaDados.map {
            "Nome: ${it.nomeproduto}\nValor: R$ ${it.valorproduto}"
        })

        val lista = findViewById<ListView>(R.id.lstprotuto)
        lista.adapter = adapter
    }

    private fun Excluirproduto(id: String) {
        val documento = db.collection("produto").document(id)

        documento.delete()
            .addOnSuccessListener {
                Toast.makeText(this, "produto excluído", Toast.LENGTH_SHORT).show()
                BuscarprodutoFirebase()
            }
            .addOnFailureListener{
                Toast.makeText(this, "Falha ao excluir produto", Toast.LENGTH_SHORT).show()
            }
    }
}